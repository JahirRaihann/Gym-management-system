<?php

$con=mysqli_connect("localhost", "root", "", "gym_management_version1");

//mysql_select_db("fitness_club");

//mysql_select_db('fitness_club');
// Check connection
?>